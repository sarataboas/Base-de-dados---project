import warnings
warnings.filterwarnings("ignore", category=FutureWarning)
from flask import render_template, Flask
import logging
import db

APP = Flask(__name__)

# Start page
@APP.route('/')
def index():
  stats = {}
  stats = db.execute('''
   SELECT * FROM
      (SELECT COUNT(*) n_atletas FROM Atletas)
      JOIN
      (SELECT COUNT(*) n_modalidades FROM Modalidades)   
      JOIN
      (SELECT COUNT(*) n_categorias FROM Categorias) 
      JOIN 
      (SELECT COUNT(*) n_eventos FROM Eventos)       
      JOIN
      (SELECT COUNT(*) n_equipas FROM Equipas)
  ''').fetchone()
  logging.info(stats)
  return render_template('index.html',stats = stats)



